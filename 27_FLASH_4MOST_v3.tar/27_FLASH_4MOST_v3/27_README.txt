The updated file 27_FLASH_4MOST_updated.fits contains a list of 9 123 targets for the project 'The host galaxies of compact radio sources observed by ASKAP FLASH'

This project was submitted as a 4MOST Supplementary Target proposal in September 2025. 
PI: Elaine Sadler (University of Sydney, Australia)
co-PI: William Roster (MPE, Germany)
email: elaine.sadler@sydney.edu.au; wroster@mpe.mpg.de

** The updated catalogue was prepared in October 2025 in response to a request from the 4MOST team. 

The table columns are in the format requested by the 4MOST Supplementary Target call for proposals (July 2025). The file catalogue_description.txt gives more details. 

The file FLASH_4MOST_catalogue_description.txt contains a catalogue description prepared using the 4MOST template at: 
https://4most.mpe.mpg.de/static/manual/IWG1_Guidance.htm#astrometrics

The file target_selection_code.txt describes in more detail how the targets were selected. 
 
